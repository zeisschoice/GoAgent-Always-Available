goagent 3.2.2 正式版下载 [http://git.io/goa](https://nodeload.github.com/goagent/goagent/legacy.zip/3.0)

## 最近更新
* [1104 否] 3.2.2 正式版， 优化 iplist 筛选算法，降低连接数要求；修复根证书不能导入的 bug。
* [1018 否] 3.2.1 正式版， bug 修复，删除默认证书。

## 讨论区
* https://code.google.com/p/goagent/issues/list

## 文档
* 简易教程 https://goagent.github.io/?/wiki/SimpleGuide.md
* 图文教程 https://goagent.github.io/?/wiki/InstallGuide.md
* 常见问题 https://goagent.github.io/?/wiki/FAQ.md
* 配置介绍 https://goagent.github.io/?/wiki/ConfigIntroduce.md
* 五毛观止 https://goagent.github.io/?/wiki/SpamList.md
* 更新历史 https://goagent.github.io/?/wiki/History.md

## 代码
 * proxy.py https://github.com/goagent/goagent/tree/3.0
 * python27.exe https://github.com/goagent/pybuild
 * goagent.exe https://github.com/goagent/taskbar
